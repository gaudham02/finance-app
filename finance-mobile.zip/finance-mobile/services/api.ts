import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

// ─── IMPORTANT: Change this to your local machine IP ───────────────────────
// Find your IP: Windows → ipconfig | Mac/Linux → ifconfig
// Both phone and laptop must be on same WiFi
export const API_BASE = 'http://192.168.1.100:5000/api/v1';
// ───────────────────────────────────────────────────────────────────────────

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('auth_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const msg = err.response?.data?.message || err.message || 'Something went wrong';
    throw new Error(msg);
  }
);

// Auth
export const authAPI = {
  register: (data: any) => api.post('/users/register', data),
  login: (data: any) => api.post('/users/login', data),
  profile: () => api.get('/users/profile'),
};

// Accounts
export const accountsAPI = {
  list: (params?: any) => api.get('/accounts', { params: { limit: 50, ...params } }),
  create: (data: any) => api.post('/accounts', data),
  update: (id: string, data: any) => api.put(`/accounts/${id}`, data),
  delete: (id: string) => api.delete(`/accounts/${id}`),
};

// Transactions
export const transactionsAPI = {
  list: (params?: any) => api.get('/transactions', { params: { limit: 20, ...params } }),
  create: (data: any) => api.post('/transactions', data),
  delete: (id: string) => api.delete(`/transactions/${id}`),
  monthlySummary: (params?: any) => api.get('/transactions/summary/monthly', { params }),
  categoryBreakdown: (params?: any) => api.get('/transactions/summary/categories', { params }),
};

// Investments
export const investmentsAPI = {
  list: (params?: any) => api.get('/investments', { params: { limit: 50, ...params } }),
  summary: () => api.get('/investments/summary'),
  create: (data: any) => api.post('/investments', data),
  update: (id: string, data: any) => api.put(`/investments/${id}`, data),
  delete: (id: string) => api.delete(`/investments/${id}`),
};

// Categories
export const categoriesAPI = {
  list: (params?: any) => api.get('/categories', { params }),
  create: (data: any) => api.post('/categories', data),
  delete: (id: string) => api.delete(`/categories/${id}`),
};

// Dashboard
export const dashboardAPI = {
  get: () => api.get('/dashboard'),
  trend: (months = 6) => api.get(`/dashboard/trend?months=${months}`),
};

export default api;
