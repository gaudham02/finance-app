export const Colors = {
  bg: '#0a0f1e',
  card: '#111827',
  cardBorder: '#1f2937',
  surface: '#1a2234',
  primary: '#6366f1',
  primaryLight: '#818cf8',
  success: '#10b981',
  danger: '#ef4444',
  warning: '#f59e0b',
  info: '#3b82f6',
  text: '#f1f5f9',
  textSub: '#94a3b8',
  textMuted: '#475569',
  border: '#1f2937',
  income: '#10b981',
  expense: '#ef4444',
  transfer: '#6366f1',
};

export const Fonts = {
  regular: 400,
  medium: 500,
  semibold: 600,
  bold: 700,
  extrabold: 800,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 999,
};

export const Shadow = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
};

export const ACCOUNT_TYPES = ['BANK', 'WALLET', 'CREDIT_CARD'];
export const TRANSACTION_TYPES = ['INCOME', 'EXPENSE', 'TRANSFER'];
export const INVESTMENT_TYPES = ['STOCKS', 'MUTUAL_FUNDS', 'CRYPTO', 'FD', 'BONDS', 'OTHER'];

export const TYPE_COLORS: Record<string, string> = {
  INCOME: Colors.income,
  EXPENSE: Colors.expense,
  TRANSFER: Colors.transfer,
  BANK: Colors.info,
  WALLET: Colors.success,
  CREDIT_CARD: Colors.warning,
  STOCKS: Colors.info,
  CRYPTO: '#8b5cf6',
  MUTUAL_FUNDS: Colors.success,
  FD: Colors.warning,
  BONDS: Colors.textSub,
  OTHER: Colors.textMuted,
};

export const TYPE_ICONS: Record<string, string> = {
  INCOME: 'arrow-up-circle',
  EXPENSE: 'arrow-down-circle',
  TRANSFER: 'swap-horizontal',
  BANK: 'business',
  WALLET: 'wallet',
  CREDIT_CARD: 'card',
  STOCKS: 'trending-up',
  CRYPTO: 'logo-bitcoin',
  MUTUAL_FUNDS: 'pie-chart',
  FD: 'lock-closed',
  BONDS: 'document-text',
  OTHER: 'ellipsis-horizontal',
};
