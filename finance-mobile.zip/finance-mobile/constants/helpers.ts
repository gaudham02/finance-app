export const fmt = (amount: number, currency = 'INR'): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
};

export const fmtDate = (date: string | Date): string => {
  return new Date(date).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

export const fmtShortDate = (date: string | Date): string => {
  return new Date(date).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
  });
};

export const calcReturns = (invested: number, current: number) => {
  const returns = current - invested;
  const pct = invested ? ((returns / invested) * 100).toFixed(1) : '0';
  return { returns, pct, isPositive: returns >= 0 };
};

export const today = (): string => new Date().toISOString().split('T')[0];
