# 📱 FinanceOS Mobile — Setup Guide

## How to run WITHOUT deployment (Expo Go)

---

## Step 1 — Install Expo Go on your phone

- **Android**: https://play.google.com/store/apps/details?id=host.exp.exponent
- **iPhone**: https://apps.apple.com/app/expo-go/id982107779

---

## Step 2 — Find your laptop's local IP

**Windows:**
```
Win + R → cmd → ipconfig
Look for: IPv4 Address → e.g. 192.168.1.100
```

**Mac/Linux:**
```bash
ifconfig | grep "inet "
# or
ip addr show
```

> Both your phone and laptop must be on the **same WiFi network**

---

## Step 3 — Update API URL in the app

Open `services/api.ts` and change this line:

```ts
// Change this to YOUR laptop's IP
export const API_BASE = 'http://192.168.1.100:5000/api/v1';
//                              ^^^^^^^^^^^
//                              Your actual IP here
```

---

## Step 4 — Start the backend

```bash
cd finance-app/backend
npm install
cp .env.example .env
# Edit .env: add your MongoDB Atlas URI
npm run dev
# Should say: Server running on port 5000
```

---

## Step 5 — Start the mobile app

```bash
cd finance-mobile
npm install
npx expo start
```

You will see a **QR code** in the terminal.

---

## Step 6 — Open on phone

- **Android**: Open Expo Go → Scan QR code
- **iPhone**: Open Camera app → Point at QR code → Tap the link

✅ The app will open on your phone instantly!

---

## How it works

```
Your Laptop (WiFi: 192.168.1.100)
├── Backend running on :5000
└── Expo dev server on :8081

Your Phone (same WiFi)
└── Expo Go app
    └── Connects to 192.168.1.100:8081
        └── App calls API at 192.168.1.100:5000
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| App shows "Network Error" | Check IP in services/api.ts |
| Phone can't find QR | Make sure same WiFi network |
| Backend not reachable | Check firewall — allow port 5000 |
| "Cannot connect to Metro" | Run `npx expo start --tunnel` instead |
| iPhone won't scan | Use Expo Go app, not just camera |

### Windows Firewall fix
```
Windows Defender Firewall → Allow an app
→ Add Node.js → Allow on Private network
```

### If same WiFi doesn't work, use tunnel mode:
```bash
npx expo start --tunnel
# This works even on different networks
# Requires: npm install -g @expo/ngrok
```

---

## Project Structure

```
finance-mobile/
├── app/
│   ├── _layout.tsx          ← Root layout + auth guard
│   ├── auth/
│   │   ├── login.tsx        ← Login screen
│   │   └── register.tsx     ← Register screen
│   └── (tabs)/
│       ├── _layout.tsx      ← Tab bar config
│       ├── dashboard.tsx    ← Home with charts
│       ├── accounts.tsx     ← Account management
│       ├── transactions.tsx ← Transaction list + add
│       ├── investments.tsx  ← Portfolio tracker
│       └── profile.tsx      ← Settings + API info
├── components/
│   └── ui.tsx               ← Reusable components
├── constants/
│   ├── theme.ts             ← Colors, fonts, sizes
│   └── helpers.ts           ← Format helpers
├── services/
│   └── api.ts               ← All API calls ← EDIT IP HERE
├── store/
│   └── authStore.ts         ← Auth state (Zustand)
└── app.json                 ← Expo config
```

---

## Features

- 🔐 JWT Authentication (stored in SecureStore)
- 📊 Dashboard with line charts
- 💳 Account management (Bank, Wallet, Credit Card)
- 💸 Transaction tracking with search + filter
- 📈 Investment portfolio with returns calculation
- 👤 Profile with API connection status
- 🔄 Pull-to-refresh on all screens
- 🌙 Full dark theme

---

## Want to share with others without them needing your laptop?

### Option A — Expo EAS Build (free APK)
```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
# Downloads .apk file → share via WhatsApp/Drive
```

### Option B — Deploy backend to Railway (free)
1. Push backend to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add env vars (MONGO_URI, JWT_SECRET)
4. Get URL like: https://finance-app.railway.app
5. Update API_BASE in services/api.ts to that URL
6. Now anyone can use the app with your backend

---

## .env for backend

```env
PORT=5000
MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/finance_app
JWT_SECRET=make_this_long_and_random_abc123xyz
JWT_EXPIRES_IN=30d
NODE_ENV=development
```
