import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Dimensions } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LineChart } from 'react-native-chart-kit';
import { dashboardAPI } from '../../services/api';
import { useAuthStore } from '../../store/authStore';
import { StatCard, SectionHeader, Card, Loader, EmptyState } from '../../components/ui';
import { Colors, Radius, TYPE_COLORS } from '../../constants/theme';
import { fmt, fmtShortDate } from '../../constants/helpers';

const { width } = Dimensions.get('window');

export default function DashboardScreen() {
  const [data, setData] = useState<any>(null);
  const [trend, setTrend] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { user } = useAuthStore();

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [d, t]: any = await Promise.all([dashboardAPI.get(), dashboardAPI.trend(6)]);
      setData(d.data);
      setTrend(t.data || []);
    } catch (e) { console.log(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(true); }, []));

  if (loading) return <View style={styles.container}><Loader /></View>;
  if (!data) return <View style={styles.container}><EmptyState message="Could not load dashboard" /></View>;

  const { overview, this_month, investments, recent_transactions } = data;

  const chartData = trend.length > 0 ? {
    labels: trend.map((t: any) => t.month.split(' ')[0]),
    datasets: [
      { data: trend.map((t: any) => t.income || 0), color: () => Colors.success, strokeWidth: 2 },
      { data: trend.map((t: any) => t.expense || 0), color: () => Colors.danger, strokeWidth: 2 },
    ],
    legend: ['Income', 'Expense'],
  } : null;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.primary} />}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good {new Date().getHours() < 12 ? 'Morning' : new Date().getHours() < 17 ? 'Afternoon' : 'Evening'} 👋</Text>
          <Text style={styles.name}>{user?.name?.split(' ')[0]}</Text>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{user?.name?.[0]?.toUpperCase()}</Text>
        </View>
      </View>

      {/* Balance Hero */}
      <View style={styles.heroCard}>
        <Text style={styles.heroLabel}>Total Balance</Text>
        <Text style={styles.heroValue}>{fmt(overview.total_balance)}</Text>
        <Text style={styles.heroSub}>{overview.total_accounts} accounts</Text>
        <View style={styles.heroRow}>
          <View style={styles.heroStat}>
            <View style={[styles.heroDot, { backgroundColor: Colors.success }]} />
            <View>
              <Text style={styles.heroStatLabel}>Income</Text>
              <Text style={[styles.heroStatValue, { color: Colors.success }]}>{fmt(this_month.income)}</Text>
            </View>
          </View>
          <View style={styles.heroDivider} />
          <View style={styles.heroStat}>
            <View style={[styles.heroDot, { backgroundColor: Colors.danger }]} />
            <View>
              <Text style={styles.heroStatLabel}>Expense</Text>
              <Text style={[styles.heroStatValue, { color: Colors.danger }]}>{fmt(this_month.expense)}</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Stats */}
      <View style={styles.statsGrid}>
        <View style={{ flex: 1 }}>
          <StatCard label="Net This Month" value={fmt(this_month.net)} sub={`Savings ${this_month.savings_rate}%`} color={this_month.net >= 0 ? Colors.success : Colors.danger} icon="trending-up" />
        </View>
        <View style={{ flex: 1 }}>
          <StatCard label="Investments" value={fmt(investments?.total_current || 0)} sub={`${investments?.returns_pct || 0}% returns`} color={Colors.warning} icon="pie-chart" />
        </View>
      </View>

      {/* Trend Chart */}
      {chartData && (
        <Card style={{ marginBottom: 20 }}>
          <SectionHeader title="6-Month Trend" />
          <LineChart
            data={chartData}
            width={width - 80}
            height={180}
            chartConfig={{
              backgroundColor: Colors.card,
              backgroundGradientFrom: Colors.card,
              backgroundGradientTo: Colors.card,
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(148,163,184,${opacity})`,
              labelColor: () => Colors.textMuted,
              propsForDots: { r: '4', strokeWidth: '2' },
              formatYLabel: (v) => `₹${(parseInt(v) / 1000).toFixed(0)}k`,
            }}
            bezier
            style={{ borderRadius: 12, marginLeft: -16 }}
            withInnerLines={false}
            withOuterLines={false}
          />
        </Card>
      )}

      {/* Recent Transactions */}
      <SectionHeader title="Recent Transactions" />
      {recent_transactions?.length > 0 ? (
        <Card>
          {recent_transactions.slice(0, 5).map((t: any, i: number) => (
            <View key={t.transaction_id} style={[styles.txItem, i < recent_transactions.length - 1 && styles.txBorder]}>
              <View style={[styles.txIcon, { backgroundColor: TYPE_COLORS[t.type] + '22' }]}>
                <Ionicons name={t.type === 'INCOME' ? 'arrow-up' : 'arrow-down'} size={16} color={TYPE_COLORS[t.type]} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.txName}>{t.category_name || 'Uncategorized'}</Text>
                <Text style={styles.txDate}>{fmtShortDate(t.date)}</Text>
              </View>
              <Text style={[styles.txAmount, { color: TYPE_COLORS[t.type] }]}>
                {t.type === 'EXPENSE' ? '-' : '+'}{fmt(t.amount)}
              </Text>
            </View>
          ))}
        </Card>
      ) : (
        <EmptyState message="No transactions yet" icon="receipt-outline" />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 20, paddingTop: 56, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  greeting: { fontSize: 13, color: Colors.textMuted },
  name: { fontSize: 22, fontWeight: '800', color: Colors.text },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 17, fontWeight: '700', color: '#fff' },
  heroCard: { background: 'transparent', borderRadius: 24, padding: 24, marginBottom: 16, backgroundColor: Colors.primary, overflow: 'hidden' },
  heroLabel: { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginBottom: 8 },
  heroValue: { fontSize: 36, fontWeight: '800', color: '#fff', marginBottom: 4 },
  heroSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginBottom: 20 },
  heroRow: { flexDirection: 'row', backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 14, padding: 14, gap: 16 },
  heroStat: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  heroDot: { width: 8, height: 8, borderRadius: 4 },
  heroStatLabel: { fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 3 },
  heroStatValue: { fontSize: 15, fontWeight: '700' },
  heroDivider: { width: 0.5, backgroundColor: 'rgba(255,255,255,0.2)' },
  statsGrid: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  txItem: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12 },
  txBorder: { borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  txIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  txName: { fontSize: 14, fontWeight: '600', color: Colors.text, marginBottom: 2 },
  txDate: { fontSize: 12, color: Colors.textMuted },
  txAmount: { fontSize: 14, fontWeight: '700' },
});
