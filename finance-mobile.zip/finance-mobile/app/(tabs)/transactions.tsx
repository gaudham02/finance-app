import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Alert, TextInput } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { transactionsAPI, accountsAPI, categoriesAPI } from '../../services/api';
import { Badge, Button, BottomModal, Input, Select, Loader, EmptyState } from '../../components/ui';
import { Colors, Radius, TYPE_COLORS, TRANSACTION_TYPES } from '../../constants/theme';
import { fmt, fmtDate, today } from '../../constants/helpers';

const EMPTY_FORM = { account_id: '', type: 'EXPENSE', amount: '', category_id: '', date: today(), notes: '' };

const FilterChip = ({ label, active, onPress }: any) => (
  <TouchableOpacity onPress={onPress} style={[styles.chip, active && styles.chipActive]} activeOpacity={0.8}>
    <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
  </TouchableOpacity>
);

export default function TransactionsScreen() {
  const [txns, setTxns] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modal, setModal] = useState(false);
  const [filter, setFilter] = useState('');
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const params: any = { limit: 30 };
      if (filter) params.type = filter;
      if (search) params.search = search;
      const [t, a, c]: any = await Promise.all([
        transactionsAPI.list(params),
        accountsAPI.list(),
        categoriesAPI.list(),
      ]);
      setTxns(t.data?.transactions || []);
      setAccounts(a.data?.accounts || []);
      setCategories(c.data || []);
      if (!form.account_id && a.data?.accounts?.[0]) set('account_id', a.data.accounts[0].account_id);
    } catch (e) { console.log(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(true); }, [filter, search]));

  const save = async () => {
    if (!form.account_id || !form.amount) return Alert.alert('Error', 'Account and amount required');
    setSaving(true);
    try {
      const cat = categories.find(c => c.category_id === form.category_id);
      await transactionsAPI.create({ ...form, amount: Number(form.amount), category_name: cat?.name || '' });
      setModal(false);
      setForm(EMPTY_FORM);
      load(true);
    } catch (err: any) { Alert.alert('Error', err.message); }
    finally { setSaving(false); }
  };

  const del = (id: string) => {
    Alert.alert('Delete', 'Delete this transaction?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try { await transactionsAPI.delete(id); load(true); } catch (e: any) { Alert.alert('Error', e.message); }
      }},
    ]);
  };

  const catOptions = categories
    .filter(c => c.type === form.type || c.type === 'BOTH')
    .map(c => ({ value: c.category_id, label: `${c.icon} ${c.name}` }));

  const renderItem = ({ item: t, index }: any) => (
    <TouchableOpacity onLongPress={() => del(t.transaction_id)} style={styles.txCard} activeOpacity={0.9}>
      <View style={[styles.txIcon, { backgroundColor: TYPE_COLORS[t.type] + '22' }]}>
        <Ionicons name={t.type === 'INCOME' ? 'arrow-up' : t.type === 'EXPENSE' ? 'arrow-down' : 'swap-horizontal'} size={18} color={TYPE_COLORS[t.type]} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.txCat}>{t.category_name || 'Uncategorized'}</Text>
        <Text style={styles.txDate}>{fmtDate(t.date)}{t.notes ? ` · ${t.notes}` : ''}</Text>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={[styles.txAmount, { color: TYPE_COLORS[t.type] }]}>
          {t.type === 'EXPENSE' ? '-' : '+'}{fmt(t.amount)}
        </Text>
        <Badge label={t.type} type={t.type} />
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <View style={styles.header}>
        <Text style={styles.title}>Transactions</Text>
        <TouchableOpacity onPress={() => setModal(true)} style={styles.addBtn}>
          <Ionicons name="add" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={Colors.textMuted} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search transactions..."
          placeholderTextColor={Colors.textMuted}
          value={search}
          onChangeText={setSearch}
        />
        {search ? <TouchableOpacity onPress={() => setSearch('')}><Ionicons name="close" size={18} color={Colors.textMuted} /></TouchableOpacity> : null}
      </View>

      {/* Filters */}
      <View style={styles.filters}>
        {['', 'INCOME', 'EXPENSE', 'TRANSFER'].map(f => (
          <FilterChip key={f} label={f || 'All'} active={filter === f} onPress={() => setFilter(f)} />
        ))}
      </View>

      {loading ? <Loader /> : txns.length === 0 ? (
        <EmptyState message="No transactions found" icon="receipt-outline" />
      ) : (
        <FlatList
          data={txns}
          keyExtractor={i => i.transaction_id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.primary} />}
          showsVerticalScrollIndicator={false}
        />
      )}

      <BottomModal visible={modal} onClose={() => setModal(false)} title="Add Transaction">
        <Select label="Account" value={form.account_id} onChange={v => set('account_id', v)}
          options={accounts.map(a => ({ value: a.account_id, label: `${a.name} (${fmt(a.balance)})` }))} />
        <Select label="Type" value={form.type} onChange={v => set('type', v)}
          options={TRANSACTION_TYPES.map(t => ({ value: t, label: t }))} />
        <Input label="Amount" value={form.amount} onChangeText={v => set('amount', v)} keyboardType="numeric" placeholder="0" />
        <Select label="Category" value={form.category_id} onChange={v => set('category_id', v)}
          options={[{ value: '', label: 'Select category...' }, ...catOptions]} />
        <Input label="Date" value={form.date} onChangeText={v => set('date', v)} placeholder="YYYY-MM-DD" />
        <Input label="Notes (optional)" value={form.notes} onChangeText={v => set('notes', v)} placeholder="What was this for?" />
        <View style={styles.modalBtns}>
          <Button title="Cancel" variant="ghost" onPress={() => setModal(false)} style={{ flex: 1 }} />
          <Button title="Add" onPress={save} loading={saving} style={{ flex: 2 }} />
        </View>
      </BottomModal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 56, paddingBottom: 12 },
  title: { fontSize: 26, fontWeight: '800', color: Colors.text },
  addBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.card, marginHorizontal: 20, marginBottom: 12, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 0.5, borderColor: Colors.cardBorder },
  searchInput: { flex: 1, color: Colors.text, fontSize: 14 },
  filters: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginBottom: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: Colors.card, borderWidth: 0.5, borderColor: Colors.cardBorder },
  chipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText: { fontSize: 13, fontWeight: '600', color: Colors.textMuted },
  chipTextActive: { color: '#fff' },
  txCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.card, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 0.5, borderColor: Colors.cardBorder },
  txIcon: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  txCat: { fontSize: 15, fontWeight: '600', color: Colors.text, marginBottom: 3 },
  txDate: { fontSize: 12, color: Colors.textMuted },
  txAmount: { fontSize: 15, fontWeight: '700', marginBottom: 4 },
  modalBtns: { flexDirection: 'row', gap: 12, marginTop: 8, paddingBottom: 20 },
});
