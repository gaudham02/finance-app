import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { investmentsAPI } from '../../services/api';
import { Badge, Button, BottomModal, Input, Select, StatCard, Loader, EmptyState } from '../../components/ui';
import { Colors, INVESTMENT_TYPES, TYPE_COLORS, TYPE_ICONS } from '../../constants/theme';
import { fmt, calcReturns } from '../../constants/helpers';

const EMPTY_FORM = { type: 'STOCKS', name: '', platform: '', invested_amount: '', current_value: '', buy_date: '', notes: '' };

export default function InvestmentsScreen() {
  const [investments, setInvestments] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modal, setModal] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [i, s]: any = await Promise.all([investmentsAPI.list(), investmentsAPI.summary()]);
      setInvestments(i.data?.investments || []);
      setSummary(s.data);
    } catch (e) { console.log(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(true); }, []));

  const save = async () => {
    setSaving(true);
    try {
      if (modal === 'create') {
        await investmentsAPI.create({ ...form, invested_amount: Number(form.invested_amount), current_value: Number(form.current_value) });
      } else {
        await investmentsAPI.update(modal!, { current_value: Number(form.current_value) });
      }
      setModal(null);
      setForm(EMPTY_FORM);
      load(true);
    } catch (err: any) { Alert.alert('Error', err.message); }
    finally { setSaving(false); }
  };

  const del = (id: string, name: string) => {
    Alert.alert('Delete', `Delete "${name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try { await investmentsAPI.delete(id); load(true); } catch (e: any) { Alert.alert('Error', e.message); }
      }},
    ]);
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.primary} />}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Investments</Text>
          <TouchableOpacity onPress={() => { setForm(EMPTY_FORM); setModal('create'); }} style={styles.addBtn}>
            <Ionicons name="add" size={22} color="#fff" />
          </TouchableOpacity>
        </View>

        {summary && (
          <>
            <View style={styles.statsGrid}>
              <View style={{ flex: 1 }}>
                <StatCard label="Invested" value={fmt(summary.totals.total_invested)} color={Colors.primary} icon="wallet" />
              </View>
              <View style={{ flex: 1 }}>
                <StatCard label="Current" value={fmt(summary.totals.total_current)} color={Colors.success} icon="trending-up" />
              </View>
            </View>
            <View style={[styles.returnsBanner, { backgroundColor: summary.totals.total_returns >= 0 ? Colors.success + '22' : Colors.danger + '22', borderColor: summary.totals.total_returns >= 0 ? Colors.success + '44' : Colors.danger + '44' }]}>
              <Text style={styles.returnsLabel}>Total Returns</Text>
              <Text style={[styles.returnsValue, { color: summary.totals.total_returns >= 0 ? Colors.success : Colors.danger }]}>
                {summary.totals.total_returns >= 0 ? '+' : ''}{fmt(summary.totals.total_returns)} ({summary.totals.total_returns_pct}%)
              </Text>
            </View>
          </>
        )}

        {loading ? <Loader /> : investments.length === 0 ? (
          <EmptyState message="No investments yet" icon="trending-up-outline" />
        ) : investments.map(inv => {
          const { returns, pct, isPositive } = calcReturns(inv.invested_amount, inv.current_value);
          return (
            <TouchableOpacity key={inv.investment_id} style={styles.invCard} onLongPress={() => del(inv.investment_id, inv.name)} activeOpacity={0.9}>
              <View style={styles.invTop}>
                <View style={styles.invLeft}>
                  <View style={[styles.invIcon, { backgroundColor: (TYPE_COLORS[inv.type] || Colors.primary) + '22' }]}>
                    <Ionicons name={TYPE_ICONS[inv.type] as any || 'trending-up'} size={20} color={TYPE_COLORS[inv.type] || Colors.primary} />
                  </View>
                  <View>
                    <Text style={styles.invName}>{inv.name}</Text>
                    {inv.platform ? <Text style={styles.invPlatform}>{inv.platform}</Text> : null}
                  </View>
                </View>
                <View style={styles.invActions}>
                  <TouchableOpacity onPress={() => { setForm({ ...inv, current_value: String(inv.current_value) }); setModal(inv.investment_id); }} style={styles.iconBtn}>
                    <Ionicons name="refresh" size={16} color={Colors.primary} />
                  </TouchableOpacity>
                  <Badge label={inv.type} type={inv.type} />
                </View>
              </View>
              <View style={styles.invStats}>
                <View style={styles.invStat}>
                  <Text style={styles.invStatLabel}>Invested</Text>
                  <Text style={styles.invStatValue}>{fmt(inv.invested_amount)}</Text>
                </View>
                <View style={styles.invStat}>
                  <Text style={styles.invStatLabel}>Current</Text>
                  <Text style={styles.invStatValue}>{fmt(inv.current_value)}</Text>
                </View>
                <View style={[styles.invReturn, { backgroundColor: isPositive ? Colors.success + '22' : Colors.danger + '22' }]}>
                  <Text style={styles.invStatLabel}>Returns</Text>
                  <Text style={[styles.invReturnValue, { color: isPositive ? Colors.success : Colors.danger }]}>
                    {isPositive ? '+' : ''}{pct}%
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <BottomModal visible={!!modal} onClose={() => setModal(null)} title={modal === 'create' ? 'Add Investment' : 'Update Current Value'}>
        {modal === 'create' ? (
          <>
            <Select label="Type" value={form.type} onChange={v => set('type', v)}
              options={INVESTMENT_TYPES.map(t => ({ value: t, label: t.replace('_', ' ') }))} />
            <Input label="Name" value={form.name} onChangeText={v => set('name', v)} placeholder="e.g. Reliance Industries" />
            <Input label="Platform" value={form.platform} onChangeText={v => set('platform', v)} placeholder="e.g. Zerodha" />
            <Input label="Invested Amount" value={form.invested_amount} onChangeText={v => set('invested_amount', v)} keyboardType="numeric" placeholder="0" />
            <Input label="Current Value" value={form.current_value} onChangeText={v => set('current_value', v)} keyboardType="numeric" placeholder="0" />
          </>
        ) : (
          <Input label="Current Market Value" value={form.current_value} onChangeText={v => set('current_value', v)} keyboardType="numeric" placeholder="0" />
        )}
        <View style={styles.modalBtns}>
          <Button title="Cancel" variant="ghost" onPress={() => setModal(null)} style={{ flex: 1 }} />
          <Button title="Save" onPress={save} loading={saving} style={{ flex: 2 }} />
        </View>
      </BottomModal>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 56, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 26, fontWeight: '800', color: Colors.text },
  addBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  statsGrid: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  returnsBanner: { borderRadius: 14, padding: 16, borderWidth: 0.5, marginBottom: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  returnsLabel: { fontSize: 14, color: Colors.textSub, fontWeight: '600' },
  returnsValue: { fontSize: 16, fontWeight: '800' },
  invCard: { backgroundColor: Colors.card, borderRadius: 18, padding: 16, marginBottom: 12, borderWidth: 0.5, borderColor: Colors.cardBorder },
  invTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  invLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  invIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  invName: { fontSize: 15, fontWeight: '700', color: Colors.text },
  invPlatform: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  invActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  iconBtn: { padding: 6 },
  invStats: { flexDirection: 'row', gap: 8 },
  invStat: { flex: 1, backgroundColor: Colors.surface, borderRadius: 10, padding: 10 },
  invStatLabel: { fontSize: 11, color: Colors.textMuted, marginBottom: 4 },
  invStatValue: { fontSize: 14, fontWeight: '700', color: Colors.text },
  invReturn: { flex: 1, borderRadius: 10, padding: 10 },
  invReturnValue: { fontSize: 15, fontWeight: '800' },
  modalBtns: { flexDirection: 'row', gap: 12, marginTop: 8, paddingBottom: 20 },
});
