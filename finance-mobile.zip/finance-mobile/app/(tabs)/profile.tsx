import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuthStore } from '../../store/authStore';
import { Colors, Radius } from '../../constants/theme';
import { API_BASE } from '../../services/api';

const MenuItem = ({ icon, label, value, onPress, danger = false, toggle, toggleValue, onToggle }: any) => (
  <TouchableOpacity onPress={onPress} style={styles.menuItem} activeOpacity={0.8}>
    <View style={[styles.menuIcon, { backgroundColor: danger ? Colors.danger + '22' : Colors.surface }]}>
      <Ionicons name={icon} size={18} color={danger ? Colors.danger : Colors.textSub} />
    </View>
    <Text style={[styles.menuLabel, danger && { color: Colors.danger }]}>{label}</Text>
    <View style={{ marginLeft: 'auto', flexDirection: 'row', alignItems: 'center', gap: 8 }}>
      {value ? <Text style={styles.menuValue}>{value}</Text> : null}
      {toggle ? <Switch value={toggleValue} onValueChange={onToggle} trackColor={{ true: Colors.primary }} /> : <Ionicons name="chevron-forward" size={16} color={Colors.textMuted} />}
    </View>
  </TouchableOpacity>
);

export default function ProfileScreen() {
  const { user, logout } = useAuthStore();
  const [notif, setNotif] = useState(true);

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: async () => { await logout(); router.replace('/auth/login'); } },
    ]);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Avatar */}
      <View style={styles.profileBox}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{user?.name?.[0]?.toUpperCase()}</Text>
        </View>
        <Text style={styles.name}>{user?.name}</Text>
        <Text style={styles.email}>{user?.email}</Text>
        <View style={styles.currencyBadge}>
          <Ionicons name="cash-outline" size={14} color={Colors.primary} />
          <Text style={styles.currencyText}>{user?.currency || 'INR'}</Text>
        </View>
      </View>

      {/* API Info */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>API Connection</Text>
        <View style={styles.apiCard}>
          <View style={styles.apiDot} />
          <View style={{ flex: 1 }}>
            <Text style={styles.apiLabel}>Backend URL</Text>
            <Text style={styles.apiUrl}>{API_BASE}</Text>
          </View>
          <Ionicons name="wifi" size={18} color={Colors.success} />
        </View>
        <Text style={styles.apiHint}>
          To change the backend URL, edit{'\n'}
          <Text style={{ color: Colors.primary, fontFamily: 'monospace' }}>services/api.ts → API_BASE</Text>
        </Text>
      </View>

      {/* Settings */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Preferences</Text>
        <View style={styles.menuCard}>
          <MenuItem icon="notifications-outline" label="Notifications" toggle toggleValue={notif} onToggle={setNotif} />
          <MenuItem icon="moon-outline" label="Dark Mode" value="Always On" />
          <MenuItem icon="globe-outline" label="Currency" value={user?.currency || 'INR'} onPress={() => {}} />
        </View>
      </View>

      {/* About */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>About</Text>
        <View style={styles.menuCard}>
          <MenuItem icon="information-circle-outline" label="Version" value="1.0.0" />
          <MenuItem icon="code-slash-outline" label="Stack" value="RN + Expo" />
          <MenuItem icon="server-outline" label="Backend" value="Node.js + MongoDB" />
        </View>
      </View>

      {/* Quick Tips */}
      <View style={styles.tipsCard}>
        <Text style={styles.tipsTitle}>💡 Quick Tips</Text>
        <Text style={styles.tip}>• Long press a transaction to delete it</Text>
        <Text style={styles.tip}>• Pull down to refresh any screen</Text>
        <Text style={styles.tip}>• Long press account card to edit it</Text>
        <Text style={styles.tip}>• Tap refresh icon on investment to update value</Text>
      </View>

      {/* Logout */}
      <View style={styles.section}>
        <View style={styles.menuCard}>
          <MenuItem icon="log-out-outline" label="Sign Out" danger onPress={handleLogout} />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 20, paddingTop: 56, paddingBottom: 60 },
  profileBox: { alignItems: 'center', marginBottom: 32 },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 14, borderWidth: 3, borderColor: Colors.primary + '44' },
  avatarText: { fontSize: 32, fontWeight: '800', color: '#fff' },
  name: { fontSize: 22, fontWeight: '800', color: Colors.text, marginBottom: 4 },
  email: { fontSize: 14, color: Colors.textMuted, marginBottom: 10 },
  currencyBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: Colors.primary + '22', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  currencyText: { fontSize: 13, color: Colors.primary, fontWeight: '600' },
  section: { marginBottom: 20 },
  sectionLabel: { fontSize: 12, color: Colors.textMuted, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10, fontWeight: '600' },
  menuCard: { backgroundColor: Colors.card, borderRadius: 16, borderWidth: 0.5, borderColor: Colors.cardBorder, overflow: 'hidden' },
  menuItem: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  menuIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { fontSize: 15, color: Colors.text, fontWeight: '500' },
  menuValue: { fontSize: 13, color: Colors.textMuted },
  apiCard: { backgroundColor: Colors.card, borderRadius: 14, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 0.5, borderColor: Colors.success + '44', marginBottom: 8 },
  apiDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.success },
  apiLabel: { fontSize: 11, color: Colors.textMuted, marginBottom: 2 },
  apiUrl: { fontSize: 12, color: Colors.text, fontFamily: 'monospace' },
  apiHint: { fontSize: 12, color: Colors.textMuted, lineHeight: 18 },
  tipsCard: { backgroundColor: Colors.card, borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 0.5, borderColor: Colors.cardBorder, gap: 8 },
  tipsTitle: { fontSize: 15, fontWeight: '700', color: Colors.text, marginBottom: 4 },
  tip: { fontSize: 13, color: Colors.textSub, lineHeight: 20 },
});
