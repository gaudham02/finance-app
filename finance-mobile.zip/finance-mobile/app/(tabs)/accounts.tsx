import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { accountsAPI } from '../../services/api';
import { Badge, Button, BottomModal, Input, Select, Loader, EmptyState, SectionHeader } from '../../components/ui';
import { Colors, Radius, Shadow, ACCOUNT_TYPES } from '../../constants/theme';
import { fmt } from '../../constants/helpers';

const EMPTY_FORM = { name: '', type: 'BANK', balance: '', bank_name: '', notes: '' };

export default function AccountsScreen() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modal, setModal] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res: any = await accountsAPI.list();
      setAccounts(res.data?.accounts || []);
    } catch (e) { console.log(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(true); }, []));

  const save = async () => {
    if (!form.name || !form.type) return Alert.alert('Error', 'Name and type required');
    setSaving(true);
    try {
      if (modal === 'create') await accountsAPI.create({ ...form, balance: Number(form.balance) || 0 });
      else await accountsAPI.update(modal!, { name: form.name, bank_name: form.bank_name, notes: form.notes });
      setModal(null);
      setForm(EMPTY_FORM);
      load(true);
    } catch (err: any) { Alert.alert('Error', err.message); }
    finally { setSaving(false); }
  };

  const del = (id: string, name: string) => {
    Alert.alert('Delete Account', `Delete "${name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try { await accountsAPI.delete(id); load(true); } catch (e: any) { Alert.alert('Error', e.message); }
      }},
    ]);
  };

  const openEdit = (a: any) => {
    setForm({ name: a.name, type: a.type, balance: String(a.balance), bank_name: a.bank_name || '', notes: a.notes || '' });
    setModal(a.account_id);
  };

  const totalBalance = accounts.reduce((s, a) => s + a.balance, 0);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.primary} />}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Accounts</Text>
          <TouchableOpacity onPress={() => { setForm(EMPTY_FORM); setModal('create'); }} style={styles.addBtn}>
            <Ionicons name="add" size={22} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Total Balance Banner */}
        <View style={styles.banner}>
          <Text style={styles.bannerLabel}>Total Balance</Text>
          <Text style={styles.bannerValue}>{fmt(totalBalance)}</Text>
          <Text style={styles.bannerSub}>{accounts.length} active accounts</Text>
        </View>

        {loading ? <Loader /> : accounts.length === 0 ? (
          <EmptyState message="No accounts yet. Add your first account!" icon="wallet-outline" />
        ) : (
          accounts.map(a => (
            <TouchableOpacity key={a.account_id} style={styles.accountCard} onLongPress={() => openEdit(a)} activeOpacity={0.9}>
              <View style={styles.accountTop}>
                <Badge label={a.type} type={a.type} />
                <View style={styles.accountActions}>
                  <TouchableOpacity onPress={() => openEdit(a)} style={styles.iconBtn}>
                    <Ionicons name="pencil-outline" size={16} color={Colors.textMuted} />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => del(a.account_id, a.name)} style={styles.iconBtn}>
                    <Ionicons name="trash-outline" size={16} color={Colors.danger} />
                  </TouchableOpacity>
                </View>
              </View>
              <Text style={styles.accountName}>{a.name}</Text>
              {a.bank_name ? <Text style={styles.accountBank}>{a.bank_name}</Text> : null}
              <Text style={[styles.accountBalance, { color: a.balance >= 0 ? Colors.success : Colors.danger }]}>
                {fmt(a.balance)}
              </Text>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      <BottomModal visible={!!modal} onClose={() => setModal(null)} title={modal === 'create' ? 'Add Account' : 'Edit Account'}>
        <Input label="Account Name" value={form.name} onChangeText={v => set('name', v)} placeholder="e.g. HDFC Savings" />
        {modal === 'create' && (
          <>
            <Select label="Type" value={form.type} onChange={v => set('type', v)}
              options={ACCOUNT_TYPES.map(t => ({ value: t, label: t.replace('_', ' ') }))} />
            <Input label="Opening Balance" value={form.balance} onChangeText={v => set('balance', v)} keyboardType="numeric" placeholder="0" />
          </>
        )}
        <Input label="Bank Name (optional)" value={form.bank_name} onChangeText={v => set('bank_name', v)} placeholder="HDFC Bank" />
        <Input label="Notes (optional)" value={form.notes} onChangeText={v => set('notes', v)} placeholder="Any notes..." />
        <View style={styles.modalBtns}>
          <Button title="Cancel" variant="ghost" onPress={() => setModal(null)} style={{ flex: 1 }} />
          <Button title="Save" onPress={save} loading={saving} style={{ flex: 2 }} />
        </View>
      </BottomModal>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 56, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 26, fontWeight: '800', color: Colors.text },
  addBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  banner: { backgroundColor: Colors.primary, borderRadius: 20, padding: 22, marginBottom: 20 },
  bannerLabel: { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginBottom: 6 },
  bannerValue: { fontSize: 34, fontWeight: '800', color: '#fff', marginBottom: 4 },
  bannerSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)' },
  accountCard: { backgroundColor: Colors.card, borderRadius: 18, padding: 18, marginBottom: 12, borderWidth: 0.5, borderColor: Colors.cardBorder, ...Shadow.card },
  accountTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  accountActions: { flexDirection: 'row', gap: 8 },
  iconBtn: { padding: 6 },
  accountName: { fontSize: 17, fontWeight: '700', color: Colors.text, marginBottom: 4 },
  accountBank: { fontSize: 13, color: Colors.textMuted, marginBottom: 10 },
  accountBalance: { fontSize: 26, fontWeight: '800' },
  modalBtns: { flexDirection: 'row', gap: 12, marginTop: 8, paddingBottom: 20 },
});
