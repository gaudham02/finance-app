import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, Alert, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { authAPI } from '../../services/api';
import { useAuthStore } from '../../store/authStore';
import { Button, Input, Select } from '../../components/ui';
import { Colors } from '../../constants/theme';

export default function RegisterScreen() {
  const [form, setForm] = useState({ name: '', email: '', password: '', currency: 'INR' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();

  const set = (key: string, val: string) => setForm(p => ({ ...p, [key]: val }));

  const handleRegister = async () => {
    if (!form.name || !form.email || !form.password) return Alert.alert('Error', 'Please fill all fields');
    setLoading(true);
    try {
      const res: any = await authAPI.register(form);
      await login(res.data.token, res.data.user);
      router.replace('/(tabs)/dashboard');
    } catch (err: any) {
      Alert.alert('Registration Failed', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <TouchableOpacity onPress={() => router.back()} style={styles.back}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Create Account</Text>
        <Text style={styles.subtitle}>Start managing your finances today</Text>

        <View style={styles.form}>
          <Input label="Full Name" value={form.name} onChangeText={v => set('name', v)} placeholder="John Doe" autoCapitalize="words" />
          <Input label="Email" value={form.email} onChangeText={v => set('email', v)} keyboardType="email-address" autoCapitalize="none" placeholder="you@example.com" />
          <Input label="Password" value={form.password} onChangeText={v => set('password', v)} secureTextEntry placeholder="Min 6 characters" />
          <Select label="Currency" value={form.currency} onChange={v => set('currency', v)} options={[{ value: 'INR', label: '₹ Indian Rupee' }, { value: 'USD', label: '$ US Dollar' }, { value: 'EUR', label: '€ Euro' }, { value: 'GBP', label: '£ British Pound' }]} />
          <Button title="Create Account" onPress={handleRegister} loading={loading} style={{ marginTop: 8 }} />
          <TouchableOpacity onPress={() => router.back()} style={styles.switchBtn}>
            <Text style={styles.switchText}>Already have an account? <Text style={{ color: Colors.primary }}>Sign In</Text></Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 24, paddingTop: 60 },
  back: { marginBottom: 24 },
  title: { fontSize: 28, fontWeight: '800', color: Colors.text, marginBottom: 8 },
  subtitle: { fontSize: 14, color: Colors.textMuted, marginBottom: 32 },
  form: { backgroundColor: Colors.card, borderRadius: 24, padding: 24, borderWidth: 0.5, borderColor: Colors.cardBorder },
  switchBtn: { alignItems: 'center', marginTop: 20 },
  switchText: { fontSize: 14, color: Colors.textSub },
});
