import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
  Modal, ScrollView, TextInput, Platform, Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Radius, Shadow, TYPE_COLORS } from '../constants/theme';

const { width } = Dimensions.get('window');

// ─── StatCard ──────────────────────────────────────────────────────────────
export const StatCard = ({ label, value, sub, color = Colors.primary, icon }: any) => (
  <View style={[styles.statCard, Shadow.card]}>
    <View style={styles.statRow}>
      <View style={{ flex: 1 }}>
        <Text style={styles.statLabel}>{label}</Text>
        <Text style={[styles.statValue, { color }]}>{value}</Text>
        {sub ? <Text style={styles.statSub}>{sub}</Text> : null}
      </View>
      {icon && (
        <View style={[styles.iconBox, { backgroundColor: color + '22' }]}>
          <Ionicons name={icon} size={22} color={color} />
        </View>
      )}
    </View>
    <View style={[styles.statBar, { backgroundColor: color }]} />
  </View>
);

// ─── Badge ─────────────────────────────────────────────────────────────────
export const Badge = ({ label, type }: { label: string; type: string }) => {
  const color = TYPE_COLORS[type] || Colors.textMuted;
  return (
    <View style={[styles.badge, { backgroundColor: color + '22', borderColor: color + '44' }]}>
      <Text style={[styles.badgeText, { color }]}>{label.replace('_', ' ')}</Text>
    </View>
  );
};

// ─── Button ────────────────────────────────────────────────────────────────
export const Button = ({ title, onPress, variant = 'primary', loading = false, style = {} }: any) => {
  const bg = variant === 'primary' ? Colors.primary : variant === 'danger' ? Colors.danger : variant === 'success' ? Colors.success : 'transparent';
  const textColor = variant === 'ghost' ? Colors.textSub : '#fff';
  const border = variant === 'ghost' ? { borderWidth: 1, borderColor: Colors.border } : {};
  return (
    <TouchableOpacity onPress={onPress} disabled={loading} style={[styles.btn, { backgroundColor: bg }, border, style]} activeOpacity={0.8}>
      {loading ? <ActivityIndicator color="#fff" size="small" /> : <Text style={[styles.btnText, { color: textColor }]}>{title}</Text>}
    </TouchableOpacity>
  );
};

// ─── Input ─────────────────────────────────────────────────────────────────
export const Input = ({ label, ...props }: any) => (
  <View style={styles.inputWrap}>
    {label ? <Text style={styles.inputLabel}>{label}</Text> : null}
    <TextInput
      placeholderTextColor={Colors.textMuted}
      style={styles.input}
      {...props}
    />
  </View>
);

// ─── Select ────────────────────────────────────────────────────────────────
export const Select = ({ label, value, onChange, options }: any) => {
  const [open, setOpen] = useState(false);
  const selected = options.find((o: any) => o.value === value);
  return (
    <View style={styles.inputWrap}>
      {label ? <Text style={styles.inputLabel}>{label}</Text> : null}
      <TouchableOpacity onPress={() => setOpen(true)} style={styles.select} activeOpacity={0.8}>
        <Text style={{ color: selected ? Colors.text : Colors.textMuted, fontSize: 15 }}>
          {selected?.label || 'Select...'}
        </Text>
        <Ionicons name="chevron-down" size={18} color={Colors.textMuted} />
      </TouchableOpacity>
      <Modal visible={open} transparent animationType="slide" onRequestClose={() => setOpen(false)}>
        <TouchableOpacity style={styles.modalOverlay} onPress={() => setOpen(false)} activeOpacity={1}>
          <View style={styles.selectSheet}>
            <View style={styles.sheetHandle} />
            <Text style={styles.sheetTitle}>{label || 'Select'}</Text>
            <ScrollView>
              {options.map((o: any) => (
                <TouchableOpacity
                  key={o.value}
                  onPress={() => { onChange(o.value); setOpen(false); }}
                  style={[styles.sheetItem, value === o.value && styles.sheetItemActive]}
                >
                  <Text style={[styles.sheetItemText, value === o.value && { color: Colors.primary }]}>
                    {o.label}
                  </Text>
                  {value === o.value && <Ionicons name="checkmark" size={18} color={Colors.primary} />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
};

// ─── BottomSheet Modal ─────────────────────────────────────────────────────
export const BottomModal = ({ visible, onClose, title, children }: any) => (
  <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
    <View style={styles.modalOverlay}>
      <TouchableOpacity style={{ flex: 1 }} onPress={onClose} activeOpacity={1} />
      <View style={styles.bottomSheet}>
        <View style={styles.sheetHandle} />
        <View style={styles.sheetHeader}>
          <Text style={styles.sheetTitle}>{title}</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={22} color={Colors.textSub} />
          </TouchableOpacity>
        </View>
        <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {children}
        </ScrollView>
      </View>
    </View>
  </Modal>
);

// ─── Empty State ───────────────────────────────────────────────────────────
export const EmptyState = ({ message, icon = 'folder-open-outline' }: any) => (
  <View style={styles.empty}>
    <Ionicons name={icon} size={48} color={Colors.textMuted} />
    <Text style={styles.emptyText}>{message}</Text>
  </View>
);

// ─── Loader ────────────────────────────────────────────────────────────────
export const Loader = () => (
  <View style={styles.loader}>
    <ActivityIndicator size="large" color={Colors.primary} />
  </View>
);

// ─── Section Header ────────────────────────────────────────────────────────
export const SectionHeader = ({ title, action, onAction }: any) => (
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {action && <TouchableOpacity onPress={onAction}><Text style={styles.sectionAction}>{action}</Text></TouchableOpacity>}
  </View>
);

// ─── Card ──────────────────────────────────────────────────────────────────
export const Card = ({ children, style = {} }: any) => (
  <View style={[styles.card, Shadow.card, style]}>{children}</View>
);

// ─── Styles ────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  statCard: { backgroundColor: Colors.card, borderRadius: Radius.lg, padding: 16, borderWidth: 0.5, borderColor: Colors.cardBorder, overflow: 'hidden' },
  statRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  statLabel: { fontSize: 12, color: Colors.textMuted, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  statValue: { fontSize: 22, fontWeight: '700', marginBottom: 4 },
  statSub: { fontSize: 12, color: Colors.textMuted },
  statBar: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 3 },
  iconBox: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full, borderWidth: 0.5 },
  badgeText: { fontSize: 11, fontWeight: '600' },
  btn: { paddingVertical: 14, paddingHorizontal: 20, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  btnText: { fontSize: 15, fontWeight: '600' },
  inputWrap: { marginBottom: 16 },
  inputLabel: { fontSize: 12, color: Colors.textMuted, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { backgroundColor: Colors.surface, borderWidth: 0.5, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, color: Colors.text, fontSize: 15 },
  select: { backgroundColor: Colors.surface, borderWidth: 0.5, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  selectSheet: { backgroundColor: Colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '70%' },
  bottomSheet: { backgroundColor: Colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '90%' },
  sheetHandle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  sheetTitle: { fontSize: 18, fontWeight: '700', color: Colors.text },
  sheetItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  sheetItemActive: { backgroundColor: Colors.primary + '11' },
  sheetItemText: { fontSize: 15, color: Colors.text },
  empty: { alignItems: 'center', justifyContent: 'center', padding: 48, gap: 12 },
  emptyText: { fontSize: 15, color: Colors.textMuted, textAlign: 'center' },
  loader: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: Colors.text },
  sectionAction: { fontSize: 13, color: Colors.primary, fontWeight: '600' },
  card: { backgroundColor: Colors.card, borderRadius: Radius.lg, padding: 16, borderWidth: 0.5, borderColor: Colors.cardBorder },
});
