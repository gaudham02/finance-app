const categoryService = require('./category.service');
const { successResponse } = require('../../shared/utils/helpers');

const getCategories = async (req, res) => {
  const categories = await categoryService.getCategories(req.user.user_id, req.query);
  return successResponse(res, categories, 'Categories fetched');
};

const createCategory = async (req, res) => {
  const { name, type, icon, color } = req.body;
  if (!name || !type) return res.status(400).json({ success: false, message: 'name and type required' });
  const category = await categoryService.createCategory(req.user.user_id, { name, type, icon, color });
  return successResponse(res, category, 'Category created', 201);
};

const updateCategory = async (req, res) => {
  const category = await categoryService.updateCategory(req.user.user_id, req.params.category_id, req.body);
  return successResponse(res, category, 'Category updated');
};

const deleteCategory = async (req, res) => {
  await categoryService.deleteCategory(req.user.user_id, req.params.category_id);
  return successResponse(res, null, 'Category deleted');
};

module.exports = { getCategories, createCategory, updateCategory, deleteCategory };
