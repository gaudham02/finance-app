const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const categorySchema = new mongoose.Schema(
  {
    category_id: { type: String, default: uuidv4, unique: true, index: true },
    user_id: { type: String, index: true }, // null = predefined/global
    name: { type: String, required: true, trim: true },
    type: { type: String, enum: ['INCOME', 'EXPENSE', 'BOTH'], required: true },
    icon: { type: String, default: '📁' },
    color: { type: String, default: '#6B7280' },
    is_system: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

categorySchema.index({ user_id: 1, type: 1 });

module.exports = mongoose.model('Category', categorySchema);
