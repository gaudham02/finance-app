const Category = require('./category.model');
const { generateId } = require('../../shared/utils/helpers');

const SYSTEM_CATEGORIES = [
  { name: 'Food & Dining', type: 'EXPENSE', icon: '🍔', color: '#EF4444' },
  { name: 'Transportation', type: 'EXPENSE', icon: '🚗', color: '#F97316' },
  { name: 'Shopping', type: 'EXPENSE', icon: '🛍️', color: '#EC4899' },
  { name: 'Entertainment', type: 'EXPENSE', icon: '🎬', color: '#8B5CF6' },
  { name: 'Bills & Utilities', type: 'EXPENSE', icon: '💡', color: '#EAB308' },
  { name: 'Healthcare', type: 'EXPENSE', icon: '🏥', color: '#14B8A6' },
  { name: 'Education', type: 'EXPENSE', icon: '📚', color: '#3B82F6' },
  { name: 'Travel', type: 'EXPENSE', icon: '✈️', color: '#06B6D4' },
  { name: 'Salary', type: 'INCOME', icon: '💰', color: '#22C55E' },
  { name: 'Freelance', type: 'INCOME', icon: '💻', color: '#10B981' },
  { name: 'Business', type: 'INCOME', icon: '🏢', color: '#84CC16' },
  { name: 'Investment Returns', type: 'INCOME', icon: '📈', color: '#6EE7B7' },
  { name: 'Other Income', type: 'INCOME', icon: '💵', color: '#A3E635' },
  { name: 'Other Expense', type: 'EXPENSE', icon: '📦', color: '#9CA3AF' },
];

const seedSystemCategories = async () => {
  const count = await Category.countDocuments({ is_system: true });
  if (count === 0) {
    const docs = SYSTEM_CATEGORIES.map(c => ({
      ...c,
      category_id: generateId(),
      is_system: true,
      user_id: null,
    }));
    await Category.insertMany(docs);
    console.log('System categories seeded');
  }
};

const getCategories = async (user_id, query) => {
  const filter = {
    $or: [{ user_id: null, is_system: true }, { user_id }],
    is_active: true,
  };
  if (query.type && query.type !== 'ALL') filter.type = { $in: [query.type, 'BOTH'] };
  return Category.find(filter).sort({ is_system: -1, name: 1 }).lean();
};

const createCategory = async (user_id, data) => {
  return Category.create({ ...data, user_id, category_id: generateId() });
};

const updateCategory = async (user_id, category_id, data) => {
  const category = await Category.findOneAndUpdate(
    { category_id, user_id, is_system: false },
    data,
    { new: true }
  ).lean();
  if (!category) throw Object.assign(new Error('Category not found or system category'), { statusCode: 404 });
  return category;
};

const deleteCategory = async (user_id, category_id) => {
  const category = await Category.findOneAndUpdate(
    { category_id, user_id, is_system: false },
    { is_active: false },
    { new: true }
  );
  if (!category) throw Object.assign(new Error('Category not found or system category'), { statusCode: 404 });
  return category;
};

module.exports = { seedSystemCategories, getCategories, createCategory, updateCategory, deleteCategory };
