const express = require('express');
const router = express.Router();
const { getCategories, createCategory, updateCategory, deleteCategory } = require('./category.controller');
const { authenticate } = require('../../shared/middleware/auth');

router.use(authenticate);

router.get('/', getCategories);
router.post('/', createCategory);
router.put('/:category_id', updateCategory);
router.delete('/:category_id', deleteCategory);

module.exports = router;
