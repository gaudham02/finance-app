const express = require('express');
const router = express.Router();
const { register, login, getProfile, updateProfile } = require('./user.controller');
const { authenticate } = require('../../shared/middleware/auth');

router.post('/register', register);
router.post('/login', login);
router.get('/profile', authenticate, getProfile);
router.put('/profile', authenticate, updateProfile);

module.exports = router;
