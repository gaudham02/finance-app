const userService = require('./user.service');
const { registerSchema, loginSchema } = require('./user.validator');
const { successResponse } = require('../../shared/utils/helpers');

const register = async (req, res) => {
  const { error, value } = registerSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  const result = await userService.register(value);
  return successResponse(res, result, 'User registered successfully', 201);
};

const login = async (req, res) => {
  const { error, value } = loginSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  const result = await userService.login(value);
  return successResponse(res, result, 'Login successful');
};

const getProfile = async (req, res) => {
  const user = await userService.getProfile(req.user.user_id);
  return successResponse(res, user, 'Profile fetched');
};

const updateProfile = async (req, res) => {
  const user = await userService.updateProfile(req.user.user_id, req.body);
  return successResponse(res, user, 'Profile updated');
};

module.exports = { register, login, getProfile, updateProfile };
