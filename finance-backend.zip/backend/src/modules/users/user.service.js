const jwt = require('jsonwebtoken');
const User = require('./user.model');

const register = async ({ name, email, password, currency }) => {
  const existing = await User.findOne({ email });
  if (existing) throw Object.assign(new Error('Email already registered'), { statusCode: 400 });

  const user = await User.create({ name, email, password, currency });
  const token = generateToken(user.user_id);
  return { user: { user_id: user.user_id, name: user.name, email: user.email, currency: user.currency }, token };
};

const login = async ({ email, password }) => {
  const user = await User.findOne({ email }).select('+password');
  if (!user) throw Object.assign(new Error('Invalid credentials'), { statusCode: 401 });

  const isMatch = await user.comparePassword(password);
  if (!isMatch) throw Object.assign(new Error('Invalid credentials'), { statusCode: 401 });

  const token = generateToken(user.user_id);
  return { user: { user_id: user.user_id, name: user.name, email: user.email, currency: user.currency }, token };
};

const getProfile = async (user_id) => {
  return User.findOne({ user_id }).lean();
};

const updateProfile = async (user_id, updates) => {
  return User.findOneAndUpdate({ user_id }, updates, { new: true, runValidators: true }).lean();
};

const generateToken = (user_id) => {
  return jwt.sign({ user_id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
};

module.exports = { register, login, getProfile, updateProfile };
