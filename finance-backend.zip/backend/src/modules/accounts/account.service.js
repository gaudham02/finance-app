const Account = require('./account.model');
const { getPagination, getSorting, generateId } = require('../../shared/utils/helpers');

const createAccount = async (user_id, data) => {
  const account = await Account.create({ ...data, user_id, account_id: generateId() });
  return account;
};

const getAccounts = async (user_id, query) => {
  const { page, limit, skip } = getPagination(query);
  const sort = getSorting(query, ['name', 'balance', 'createdAt']);

  const filter = { user_id, is_active: true };
  if (query.type) filter.type = query.type;

  const [accounts, total] = await Promise.all([
    Account.find(filter).sort(sort).skip(skip).limit(limit).lean(),
    Account.countDocuments(filter),
  ]);

  return { accounts, total, page, limit };
};

const getAccountById = async (user_id, account_id) => {
  const account = await Account.findOne({ account_id, user_id }).lean();
  if (!account) throw Object.assign(new Error('Account not found'), { statusCode: 404 });
  return account;
};

const updateAccount = async (user_id, account_id, data) => {
  const account = await Account.findOneAndUpdate(
    { account_id, user_id },
    data,
    { new: true, runValidators: true }
  ).lean();
  if (!account) throw Object.assign(new Error('Account not found'), { statusCode: 404 });
  return account;
};

const deleteAccount = async (user_id, account_id) => {
  const account = await Account.findOneAndUpdate(
    { account_id, user_id },
    { is_active: false },
    { new: true }
  ).lean();
  if (!account) throw Object.assign(new Error('Account not found'), { statusCode: 404 });
  return account;
};

const updateBalance = async (account_id, amount, session = null) => {
  const opts = session ? { session } : {};
  return Account.findOneAndUpdate(
    { account_id },
    { $inc: { balance: amount } },
    { new: true, ...opts }
  );
};

module.exports = { createAccount, getAccounts, getAccountById, updateAccount, deleteAccount, updateBalance };
