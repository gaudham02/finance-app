const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const ACCOUNT_TYPES = ['BANK', 'WALLET', 'CREDIT_CARD'];

const accountSchema = new mongoose.Schema(
  {
    account_id: { type: String, default: uuidv4, unique: true, index: true },
    user_id: { type: String, required: true, index: true },
    name: { type: String, required: true, trim: true },
    type: { type: String, enum: ACCOUNT_TYPES, required: true },
    balance: { type: Number, default: 0 },
    currency: { type: String, default: 'INR' },
    bank_name: { type: String },
    account_number: { type: String },
    color: { type: String, default: '#4F46E5' },
    is_active: { type: Boolean, default: true },
    notes: { type: String },
  },
  { timestamps: true }
);

accountSchema.index({ user_id: 1, is_active: 1 });

module.exports = mongoose.model('Account', accountSchema);
module.exports.ACCOUNT_TYPES = ACCOUNT_TYPES;
