const Joi = require('joi');
const { ACCOUNT_TYPES } = require('./account.model');

const createAccountSchema = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  type: Joi.string().valid(...ACCOUNT_TYPES).required(),
  balance: Joi.number().default(0),
  currency: Joi.string().default('INR'),
  bank_name: Joi.string().optional(),
  account_number: Joi.string().optional(),
  color: Joi.string().optional(),
  notes: Joi.string().optional(),
});

const updateAccountSchema = Joi.object({
  name: Joi.string().min(2).max(100),
  balance: Joi.number(),
  bank_name: Joi.string(),
  color: Joi.string(),
  notes: Joi.string(),
});

module.exports = { createAccountSchema, updateAccountSchema };
