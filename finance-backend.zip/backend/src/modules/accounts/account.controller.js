const accountService = require('./account.service');
const { createAccountSchema, updateAccountSchema } = require('./account.validator');
const { successResponse, paginatedResponse } = require('../../shared/utils/helpers');

const createAccount = async (req, res) => {
  const { error, value } = createAccountSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  const account = await accountService.createAccount(req.user.user_id, value);
  return successResponse(res, account, 'Account created', 201);
};

const getAccounts = async (req, res) => {
  const { accounts, total, page, limit } = await accountService.getAccounts(req.user.user_id, req.query);
  return paginatedResponse(res, accounts, total, page, limit, 'Accounts fetched');
};

const getAccountById = async (req, res) => {
  const account = await accountService.getAccountById(req.user.user_id, req.params.account_id);
  return successResponse(res, account, 'Account fetched');
};

const updateAccount = async (req, res) => {
  const { error, value } = updateAccountSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  const account = await accountService.updateAccount(req.user.user_id, req.params.account_id, value);
  return successResponse(res, account, 'Account updated');
};

const deleteAccount = async (req, res) => {
  await accountService.deleteAccount(req.user.user_id, req.params.account_id);
  return successResponse(res, null, 'Account deleted');
};

module.exports = { createAccount, getAccounts, getAccountById, updateAccount, deleteAccount };
