const express = require('express');
const router = express.Router();
const { createAccount, getAccounts, getAccountById, updateAccount, deleteAccount } = require('./account.controller');
const { authenticate } = require('../../shared/middleware/auth');

router.use(authenticate);

router.post('/', createAccount);
router.get('/', getAccounts);
router.get('/:account_id', getAccountById);
router.put('/:account_id', updateAccount);
router.delete('/:account_id', deleteAccount);

module.exports = router;
