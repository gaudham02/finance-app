const express = require('express');
const router = express.Router();
const {
  createTransaction, getTransactions, getTransactionById,
  updateTransaction, deleteTransaction, getMonthlySummary,
  getCategoryBreakdown, importCSV,
} = require('./transaction.controller');
const { authenticate } = require('../../shared/middleware/auth');

router.use(authenticate);

router.post('/', createTransaction);
router.get('/', getTransactions);
router.get('/summary/monthly', getMonthlySummary);
router.get('/summary/categories', getCategoryBreakdown);
router.post('/import/csv', importCSV);
router.get('/:transaction_id', getTransactionById);
router.put('/:transaction_id', updateTransaction);
router.delete('/:transaction_id', deleteTransaction);

module.exports = router;
