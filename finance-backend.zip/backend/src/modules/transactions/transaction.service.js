const mongoose = require('mongoose');
const Transaction = require('./transaction.model');
const { updateBalance } = require('../accounts/account.service');
const { getPagination, getSorting, generateId } = require('../../shared/utils/helpers');

const createTransaction = async (user_id, data) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const transaction = await Transaction.create(
      [{ ...data, user_id, transaction_id: generateId() }],
      { session }
    );

    // Update account balance
    if (data.type === 'INCOME') {
      await updateBalance(data.account_id, data.amount, session);
    } else if (data.type === 'EXPENSE') {
      await updateBalance(data.account_id, -data.amount, session);
    } else if (data.type === 'TRANSFER') {
      await updateBalance(data.account_id, -data.amount, session);
      await updateBalance(data.to_account_id, data.amount, session);
    }

    await session.commitTransaction();
    return transaction[0];
  } catch (err) {
    await session.abortTransaction();
    throw err;
  } finally {
    session.endSession();
  }
};

const getTransactions = async (user_id, query) => {
  const { page, limit, skip } = getPagination(query);
  const sort = getSorting(query, ['amount', 'date', 'createdAt']);

  const filter = { user_id, is_deleted: false };
  if (query.type) filter.type = query.type;
  if (query.account_id) filter.account_id = query.account_id;
  if (query.category_id) filter.category_id = query.category_id;
  if (query.from_date || query.to_date) {
    filter.date = {};
    if (query.from_date) filter.date.$gte = new Date(query.from_date);
    if (query.to_date) filter.date.$lte = new Date(query.to_date);
  }
  if (query.search) {
    filter.$or = [
      { notes: { $regex: query.search, $options: 'i' } },
      { category_name: { $regex: query.search, $options: 'i' } },
      { reference: { $regex: query.search, $options: 'i' } },
    ];
  }

  const [transactions, total] = await Promise.all([
    Transaction.find(filter).sort(sort).skip(skip).limit(limit).lean(),
    Transaction.countDocuments(filter),
  ]);

  return { transactions, total, page, limit };
};

const getTransactionById = async (user_id, transaction_id) => {
  const transaction = await Transaction.findOne({ transaction_id, user_id, is_deleted: false }).lean();
  if (!transaction) throw Object.assign(new Error('Transaction not found'), { statusCode: 404 });
  return transaction;
};

const updateTransaction = async (user_id, transaction_id, data) => {
  const transaction = await Transaction.findOneAndUpdate(
    { transaction_id, user_id, is_deleted: false },
    data,
    { new: true, runValidators: true }
  ).lean();
  if (!transaction) throw Object.assign(new Error('Transaction not found'), { statusCode: 404 });
  return transaction;
};

const deleteTransaction = async (user_id, transaction_id) => {
  const transaction = await Transaction.findOneAndUpdate(
    { transaction_id, user_id },
    { is_deleted: true },
    { new: true }
  ).lean();
  if (!transaction) throw Object.assign(new Error('Transaction not found'), { statusCode: 404 });
  return transaction;
};

const getMonthlySummary = async (user_id, year, month) => {
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0, 23, 59, 59);

  const result = await Transaction.aggregate([
    { $match: { user_id, is_deleted: false, date: { $gte: start, $lte: end } } },
    {
      $group: {
        _id: '$type',
        total: { $sum: '$amount' },
        count: { $sum: 1 },
      },
    },
  ]);

  const summary = { INCOME: 0, EXPENSE: 0, TRANSFER: 0, count: 0 };
  result.forEach(r => {
    summary[r._id] = r.total;
    summary.count += r.count;
  });
  summary.net = summary.INCOME - summary.EXPENSE;
  return summary;
};

const getCategoryBreakdown = async (user_id, from_date, to_date) => {
  return Transaction.aggregate([
    {
      $match: {
        user_id,
        is_deleted: false,
        type: 'EXPENSE',
        date: { $gte: new Date(from_date), $lte: new Date(to_date) },
      },
    },
    {
      $group: {
        _id: { category_id: '$category_id', category_name: '$category_name' },
        total: { $sum: '$amount' },
        count: { $sum: 1 },
      },
    },
    { $sort: { total: -1 } },
  ]);
};

const importFromCSV = async (user_id, transactions) => {
  const docs = transactions.map(t => ({ ...t, user_id, transaction_id: generateId() }));
  return Transaction.insertMany(docs, { ordered: false });
};

module.exports = {
  createTransaction,
  getTransactions,
  getTransactionById,
  updateTransaction,
  deleteTransaction,
  getMonthlySummary,
  getCategoryBreakdown,
  importFromCSV,
};
