const Joi = require('joi');
const { TRANSACTION_TYPES } = require('./transaction.model');

const createTransactionSchema = Joi.object({
  account_id: Joi.string().required(),
  to_account_id: Joi.string().when('type', { is: 'TRANSFER', then: Joi.required() }),
  type: Joi.string().valid(...TRANSACTION_TYPES).required(),
  amount: Joi.number().positive().required(),
  category_id: Joi.string().optional(),
  category_name: Joi.string().optional(),
  date: Joi.date().default(Date.now),
  notes: Joi.string().max(500).optional(),
  reference: Joi.string().optional(),
  tags: Joi.array().items(Joi.string()).optional(),
  metadata: Joi.object().optional(),
});

const updateTransactionSchema = Joi.object({
  category_id: Joi.string(),
  category_name: Joi.string(),
  date: Joi.date(),
  notes: Joi.string().max(500),
  reference: Joi.string(),
  tags: Joi.array().items(Joi.string()),
});

module.exports = { createTransactionSchema, updateTransactionSchema };
