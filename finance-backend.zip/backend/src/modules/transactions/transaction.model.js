const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const TRANSACTION_TYPES = ['INCOME', 'EXPENSE', 'TRANSFER'];

const transactionSchema = new mongoose.Schema(
  {
    transaction_id: { type: String, default: uuidv4, unique: true, index: true },
    user_id: { type: String, required: true, index: true },
    account_id: { type: String, required: true, index: true },
    to_account_id: { type: String }, // for TRANSFER
    type: { type: String, enum: TRANSACTION_TYPES, required: true },
    amount: { type: Number, required: true, min: 0 },
    category_id: { type: String },
    category_name: { type: String },
    date: { type: Date, default: Date.now, index: true },
    notes: { type: String },
    reference: { type: String },
    tags: [{ type: String }],
    metadata: { type: mongoose.Schema.Types.Mixed },
    is_deleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

transactionSchema.index({ user_id: 1, date: -1 });
transactionSchema.index({ user_id: 1, type: 1, date: -1 });
transactionSchema.index({ account_id: 1, date: -1 });

module.exports = mongoose.model('Transaction', transactionSchema);
module.exports.TRANSACTION_TYPES = TRANSACTION_TYPES;
