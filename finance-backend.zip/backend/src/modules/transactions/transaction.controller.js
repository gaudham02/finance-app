const transactionService = require('./transaction.service');
const { createTransactionSchema, updateTransactionSchema } = require('./transaction.validator');
const { successResponse, paginatedResponse } = require('../../shared/utils/helpers');
const multer = require('multer');
const { parse } = require('csv-parse/sync');

const upload = multer({ storage: multer.memoryStorage() });

const createTransaction = async (req, res) => {
  const { error, value } = createTransactionSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  const transaction = await transactionService.createTransaction(req.user.user_id, value);
  return successResponse(res, transaction, 'Transaction created', 201);
};

const getTransactions = async (req, res) => {
  const { transactions, total, page, limit } = await transactionService.getTransactions(req.user.user_id, req.query);
  return paginatedResponse(res, transactions, total, page, limit, 'Transactions fetched');
};

const getTransactionById = async (req, res) => {
  const transaction = await transactionService.getTransactionById(req.user.user_id, req.params.transaction_id);
  return successResponse(res, transaction, 'Transaction fetched');
};

const updateTransaction = async (req, res) => {
  const { error, value } = updateTransactionSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  const transaction = await transactionService.updateTransaction(req.user.user_id, req.params.transaction_id, value);
  return successResponse(res, transaction, 'Transaction updated');
};

const deleteTransaction = async (req, res) => {
  await transactionService.deleteTransaction(req.user.user_id, req.params.transaction_id);
  return successResponse(res, null, 'Transaction deleted');
};

const getMonthlySummary = async (req, res) => {
  const { year, month } = req.query;
  const now = new Date();
  const summary = await transactionService.getMonthlySummary(
    req.user.user_id,
    parseInt(year) || now.getFullYear(),
    parseInt(month) || now.getMonth() + 1
  );
  return successResponse(res, summary, 'Monthly summary fetched');
};

const getCategoryBreakdown = async (req, res) => {
  const { from_date, to_date } = req.query;
  const now = new Date();
  const breakdown = await transactionService.getCategoryBreakdown(
    req.user.user_id,
    from_date || new Date(now.getFullYear(), now.getMonth(), 1),
    to_date || now
  );
  return successResponse(res, breakdown, 'Category breakdown fetched');
};

const importCSV = [
  upload.single('file'),
  async (req, res) => {
    if (!req.file) return res.status(400).json({ success: false, message: 'CSV file required' });

    const records = parse(req.file.buffer.toString(), {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });

    const transactions = records.map(r => ({
      account_id: r.account_id,
      type: r.type?.toUpperCase(),
      amount: parseFloat(r.amount),
      category_name: r.category,
      date: r.date ? new Date(r.date) : new Date(),
      notes: r.notes,
    }));

    const result = await transactionService.importFromCSV(req.user.user_id, transactions);
    return successResponse(res, { imported: result.length }, 'CSV imported successfully');
  },
];

module.exports = {
  createTransaction,
  getTransactions,
  getTransactionById,
  updateTransaction,
  deleteTransaction,
  getMonthlySummary,
  getCategoryBreakdown,
  importCSV,
};
