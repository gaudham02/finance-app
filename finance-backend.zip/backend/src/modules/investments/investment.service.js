const Investment = require('./investment.model');
const { getPagination, getSorting, generateId } = require('../../shared/utils/helpers');

const createInvestment = async (user_id, data) => {
  return Investment.create({ ...data, user_id, investment_id: generateId() });
};

const getInvestments = async (user_id, query) => {
  const { page, limit, skip } = getPagination(query);
  const sort = getSorting(query, ['name', 'invested_amount', 'current_value', 'createdAt']);

  const filter = { user_id, is_active: true };
  if (query.type) filter.type = query.type;
  if (query.platform) filter.platform = { $regex: query.platform, $options: 'i' };

  const [investments, total] = await Promise.all([
    Investment.find(filter).sort(sort).skip(skip).limit(limit).lean({ virtuals: true }),
    Investment.countDocuments(filter),
  ]);

  return { investments, total, page, limit };
};

const getInvestmentById = async (user_id, investment_id) => {
  const investment = await Investment.findOne({ investment_id, user_id, is_active: true }).lean({ virtuals: true });
  if (!investment) throw Object.assign(new Error('Investment not found'), { statusCode: 404 });
  return investment;
};

const updateInvestment = async (user_id, investment_id, data) => {
  const investment = await Investment.findOneAndUpdate(
    { investment_id, user_id },
    data,
    { new: true, runValidators: true }
  ).lean({ virtuals: true });
  if (!investment) throw Object.assign(new Error('Investment not found'), { statusCode: 404 });
  return investment;
};

const deleteInvestment = async (user_id, investment_id) => {
  const investment = await Investment.findOneAndUpdate(
    { investment_id, user_id },
    { is_active: false },
    { new: true }
  );
  if (!investment) throw Object.assign(new Error('Investment not found'), { statusCode: 404 });
  return investment;
};

const getInvestmentSummary = async (user_id) => {
  const result = await Investment.aggregate([
    { $match: { user_id, is_active: true } },
    {
      $group: {
        _id: '$type',
        total_invested: { $sum: '$invested_amount' },
        total_current: { $sum: '$current_value' },
        count: { $sum: 1 },
      },
    },
    {
      $project: {
        type: '$_id',
        total_invested: 1,
        total_current: 1,
        count: 1,
        returns: { $subtract: ['$total_current', '$total_invested'] },
        returns_pct: {
          $multiply: [
            { $divide: [{ $subtract: ['$total_current', '$total_invested'] }, '$total_invested'] },
            100,
          ],
        },
      },
    },
  ]);

  const totals = result.reduce(
    (acc, r) => {
      acc.total_invested += r.total_invested;
      acc.total_current += r.total_current;
      return acc;
    },
    { total_invested: 0, total_current: 0 }
  );

  totals.total_returns = totals.total_current - totals.total_invested;
  totals.total_returns_pct = totals.total_invested
    ? ((totals.total_returns / totals.total_invested) * 100).toFixed(2)
    : 0;

  return { by_type: result, totals };
};

module.exports = { createInvestment, getInvestments, getInvestmentById, updateInvestment, deleteInvestment, getInvestmentSummary };
