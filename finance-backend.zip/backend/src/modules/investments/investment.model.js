const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const INVESTMENT_TYPES = ['STOCKS', 'MUTUAL_FUNDS', 'CRYPTO', 'FD', 'BONDS', 'REAL_ESTATE', 'OTHER'];

const investmentSchema = new mongoose.Schema(
  {
    investment_id: { type: String, default: uuidv4, unique: true, index: true },
    user_id: { type: String, required: true, index: true },
    type: { type: String, enum: INVESTMENT_TYPES, required: true },
    name: { type: String, required: true, trim: true },
    symbol: { type: String },
    platform: { type: String },
    invested_amount: { type: Number, required: true, min: 0 },
    current_value: { type: Number, required: true, min: 0 },
    quantity: { type: Number },
    buy_price: { type: Number },
    current_price: { type: Number },
    buy_date: { type: Date },
    maturity_date: { type: Date },
    interest_rate: { type: Number },
    notes: { type: String },
    is_active: { type: Boolean, default: true },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

investmentSchema.virtual('returns').get(function () {
  return this.current_value - this.invested_amount;
});

investmentSchema.virtual('returns_percentage').get(function () {
  if (!this.invested_amount) return 0;
  return (((this.current_value - this.invested_amount) / this.invested_amount) * 100).toFixed(2);
});

investmentSchema.index({ user_id: 1, type: 1 });

module.exports = mongoose.model('Investment', investmentSchema);
module.exports.INVESTMENT_TYPES = INVESTMENT_TYPES;
