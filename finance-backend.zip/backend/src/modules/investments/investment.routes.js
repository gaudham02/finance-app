const express = require('express');
const router = express.Router();
const { createInvestment, getInvestments, getInvestmentById, updateInvestment, deleteInvestment, getInvestmentSummary } = require('./investment.controller');
const { authenticate } = require('../../shared/middleware/auth');

router.use(authenticate);

router.post('/', createInvestment);
router.get('/', getInvestments);
router.get('/summary', getInvestmentSummary);
router.get('/:investment_id', getInvestmentById);
router.put('/:investment_id', updateInvestment);
router.delete('/:investment_id', deleteInvestment);

module.exports = router;
