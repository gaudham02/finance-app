// investment.validator.js
const Joi = require('joi');
const { INVESTMENT_TYPES } = require('./investment.model');

const createInvestmentSchema = Joi.object({
  type: Joi.string().valid(...INVESTMENT_TYPES).required(),
  name: Joi.string().min(2).max(100).required(),
  symbol: Joi.string().optional(),
  platform: Joi.string().optional(),
  invested_amount: Joi.number().positive().required(),
  current_value: Joi.number().min(0).required(),
  quantity: Joi.number().optional(),
  buy_price: Joi.number().optional(),
  current_price: Joi.number().optional(),
  buy_date: Joi.date().optional(),
  maturity_date: Joi.date().optional(),
  interest_rate: Joi.number().optional(),
  notes: Joi.string().optional(),
});

const updateInvestmentSchema = Joi.object({
  current_value: Joi.number().min(0),
  current_price: Joi.number(),
  quantity: Joi.number(),
  notes: Joi.string(),
  maturity_date: Joi.date(),
});

module.exports = { createInvestmentSchema, updateInvestmentSchema };
