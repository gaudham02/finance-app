const investmentService = require('./investment.service');
const { createInvestmentSchema, updateInvestmentSchema } = require('./investment.validator');
const { successResponse, paginatedResponse } = require('../../shared/utils/helpers');

const createInvestment = async (req, res) => {
  const { error, value } = createInvestmentSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });
  const investment = await investmentService.createInvestment(req.user.user_id, value);
  return successResponse(res, investment, 'Investment created', 201);
};

const getInvestments = async (req, res) => {
  const { investments, total, page, limit } = await investmentService.getInvestments(req.user.user_id, req.query);
  return paginatedResponse(res, investments, total, page, limit, 'Investments fetched');
};

const getInvestmentById = async (req, res) => {
  const investment = await investmentService.getInvestmentById(req.user.user_id, req.params.investment_id);
  return successResponse(res, investment, 'Investment fetched');
};

const updateInvestment = async (req, res) => {
  const { error, value } = updateInvestmentSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });
  const investment = await investmentService.updateInvestment(req.user.user_id, req.params.investment_id, value);
  return successResponse(res, investment, 'Investment updated');
};

const deleteInvestment = async (req, res) => {
  await investmentService.deleteInvestment(req.user.user_id, req.params.investment_id);
  return successResponse(res, null, 'Investment deleted');
};

const getInvestmentSummary = async (req, res) => {
  const summary = await investmentService.getInvestmentSummary(req.user.user_id);
  return successResponse(res, summary, 'Investment summary fetched');
};

module.exports = { createInvestment, getInvestments, getInvestmentById, updateInvestment, deleteInvestment, getInvestmentSummary };
