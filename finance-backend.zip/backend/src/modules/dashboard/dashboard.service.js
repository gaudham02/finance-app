const Account = require('../accounts/account.model');
const Transaction = require('../transactions/transaction.model');
const Investment = require('../investments/investment.model');

const getDashboard = async (user_id) => {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

  const [
    accounts,
    monthlyStats,
    lastMonthStats,
    investmentSummary,
    recentTransactions,
    categoryBreakdown,
  ] = await Promise.all([
    // All active accounts
    Account.find({ user_id, is_active: true }).lean(),

    // This month income/expense
    Transaction.aggregate([
      { $match: { user_id, is_deleted: false, date: { $gte: startOfMonth } } },
      { $group: { _id: '$type', total: { $sum: '$amount' }, count: { $sum: 1 } } },
    ]),

    // Last month income/expense
    Transaction.aggregate([
      { $match: { user_id, is_deleted: false, date: { $gte: startOfLastMonth, $lte: endOfLastMonth } } },
      { $group: { _id: '$type', total: { $sum: '$amount' } } },
    ]),

    // Investment summary
    Investment.aggregate([
      { $match: { user_id, is_active: true } },
      {
        $group: {
          _id: null,
          total_invested: { $sum: '$invested_amount' },
          total_current: { $sum: '$current_value' },
          count: { $sum: 1 },
        },
      },
    ]),

    // Recent 5 transactions
    Transaction.find({ user_id, is_deleted: false })
      .sort({ date: -1 })
      .limit(5)
      .lean(),

    // Top 5 expense categories this month
    Transaction.aggregate([
      { $match: { user_id, is_deleted: false, type: 'EXPENSE', date: { $gte: startOfMonth } } },
      { $group: { _id: '$category_name', total: { $sum: '$amount' }, count: { $sum: 1 } } },
      { $sort: { total: -1 } },
      { $limit: 5 },
    ]),
  ]);

  // Process account totals
  const totalBalance = accounts.reduce((sum, a) => sum + a.balance, 0);
  const accountsByType = accounts.reduce((acc, a) => {
    if (!acc[a.type]) acc[a.type] = { count: 0, balance: 0 };
    acc[a.type].count++;
    acc[a.type].balance += a.balance;
    return acc;
  }, {});

  // Process monthly stats
  const thisMonth = { INCOME: 0, EXPENSE: 0 };
  monthlyStats.forEach(s => { if (s._id !== 'TRANSFER') thisMonth[s._id] = s.total; });

  const lastMonth = { INCOME: 0, EXPENSE: 0 };
  lastMonthStats.forEach(s => { if (s._id !== 'TRANSFER') lastMonth[s._id] = s.total; });

  // Investment totals
  const investments = investmentSummary[0] || { total_invested: 0, total_current: 0, count: 0 };
  investments.returns = investments.total_current - investments.total_invested;
  investments.returns_pct = investments.total_invested
    ? ((investments.returns / investments.total_invested) * 100).toFixed(2)
    : 0;

  return {
    overview: {
      total_balance: totalBalance,
      total_accounts: accounts.length,
      accounts_by_type: accountsByType,
    },
    this_month: {
      income: thisMonth.INCOME,
      expense: thisMonth.EXPENSE,
      net: thisMonth.INCOME - thisMonth.EXPENSE,
      savings_rate: thisMonth.INCOME
        ? (((thisMonth.INCOME - thisMonth.EXPENSE) / thisMonth.INCOME) * 100).toFixed(1)
        : 0,
    },
    last_month: {
      income: lastMonth.INCOME,
      expense: lastMonth.EXPENSE,
      net: lastMonth.INCOME - lastMonth.EXPENSE,
    },
    investments,
    recent_transactions: recentTransactions,
    top_expense_categories: categoryBreakdown,
  };
};

const getMonthlyTrend = async (user_id, months = 6) => {
  const result = [];
  const now = new Date();

  for (let i = months - 1; i >= 0; i--) {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);

    const stats = await Transaction.aggregate([
      { $match: { user_id, is_deleted: false, date: { $gte: start, $lte: end }, type: { $in: ['INCOME', 'EXPENSE'] } } },
      { $group: { _id: '$type', total: { $sum: '$amount' } } },
    ]);

    const month = { month: start.toLocaleString('default', { month: 'short', year: 'numeric' }), income: 0, expense: 0 };
    stats.forEach(s => { month[s._id.toLowerCase()] = s.total; });
    month.net = month.income - month.expense;
    result.push(month);
  }

  return result;
};

module.exports = { getDashboard, getMonthlyTrend };
