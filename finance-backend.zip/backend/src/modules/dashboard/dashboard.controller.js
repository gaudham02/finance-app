const dashboardService = require('./dashboard.service');
const { successResponse } = require('../../shared/utils/helpers');

const getDashboard = async (req, res) => {
  const data = await dashboardService.getDashboard(req.user.user_id);
  return successResponse(res, data, 'Dashboard fetched');
};

const getMonthlyTrend = async (req, res) => {
  const months = parseInt(req.query.months) || 6;
  const data = await dashboardService.getMonthlyTrend(req.user.user_id, months);
  return successResponse(res, data, 'Monthly trend fetched');
};

module.exports = { getDashboard, getMonthlyTrend };
