const express = require('express');
const router = express.Router();
const { getDashboard, getMonthlyTrend } = require('./dashboard.controller');
const { authenticate } = require('../../shared/middleware/auth');

router.use(authenticate);

router.get('/', getDashboard);
router.get('/trend', getMonthlyTrend);

module.exports = router;
